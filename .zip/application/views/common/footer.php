 </div>
 <button onclick="topFunction()" class="btn btn-danger btn-icon" id="back-to-top">
   <i class="ri-arrow-up-line"></i>
 </button>
 <div id="preloader">
   <div id="status">
     <div class="spinner-border text-primary avatar-sm" role="status">
       <span class="visually-hidden">Loading...</span>
     </div>
   </div>
 </div>
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/simplebar/simplebar.min.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/node-waves/waves.min.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/feather-icons/feather.min.js"></script>
 <script src="<?php echo base_url() ?>assets/js/pages/plugins/lord-icon-2.1.0.js"></script>
 <script src="<?php echo base_url() ?>assets/js/plugins.js"></script>

 <script src="<?php echo base_url() ?>assets/js/pages/form-wizard.init.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/feather-icons/feather.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
 <script src="<?php echo base_url() ?>assets/js/common.js"></script>
 <script src="<?php echo base_url() ?>assets/js/app.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/glightbox/js/glightbox.min.js"></script>
 <script src="<?php echo base_url() ?>assets/js/pages/gallery.init.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/%40ckeditor/ckeditor5-build-classic/build/ckeditor.js"></script>

 <script src="<?php echo base_url() ?>assets/js/pages/form-editor.init.js"></script>

 </body>

 </html>